"""
🦖 Restaceratops Core Package
Core application logic and business services
""" 