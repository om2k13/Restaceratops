"""
🦖 Restaceratops Backend Package
AI-powered API testing platform backend
"""

__version__ = "2.0.0"
__author__ = "Restaceratops Team"
__description__ = "AI-augmented API testing platform backend" 